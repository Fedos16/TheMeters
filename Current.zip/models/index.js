const DataBase = require('./base');
module.exports = {
  DataBase,
};